import torch
from torch.utils.data import Dataset
import json
import os
from PIL import Image
from utils import transform


class PascalVOCDataset(Dataset):
    """
    A PyTorch Dataset class to be used in a PyTorch DataLoader to create batches.
    """

    def __init__(self, data_folder, split):
        """
        :param data_folder: folder where data files are stored
        :param split: split, one of 'TRAIN' or 'TEST'
        :param keep_difficult: keep or discard objects that are considered difficult to detect?
        """
        self.split = split.upper()

        assert self.split in {'TRAIN_5', 'TEST_7'}#example_5=TRAIN, example_7=TEST

        self.data_folder = data_folder
        #self.keep_difficult = keep_difficult 
    

        # Read data files images and anotations(objects) share index
        with open(os.path.join(data_folder, self.split + '_images.json'), 'r') as j:
            self.images = json.load(j)
        with open(os.path.join(data_folder, self.split + '_objects.json'), 'r') as j:
            self.objects = json.load(j)

        #self.images = self.images[:20] #ONLY TAKE 5 IMG FOR DEBUGGING
        #self.objects = self.objects[:20]
        print("length",len(self.images), len(self.objects))
        assert len(self.images) == len(self.objects)

        
        

    def __getitem__(self, i):
        # Read image
        image = Image.open(self.images[i], mode='r')
        image = image.convert('RGB')

        # Read objects in this image (bounding boxes, labels, difficulties)
        objects = self.objects[i]
        # print('i=', i, 'object=', objects)
       # print('object=' ,objects, 'i =', i)
        #image_id = objects['image_id']
        #image_id =image_id - 1
        #print(image_id)
        boxes = torch.FloatTensor(objects['boxes'])  # (n_objects, 4)
        # print('boxes=',boxes)
        labels = torch.LongTensor(objects['labels'])  # (n_objects)
        # print('labels=',labels)
        #difficulties = torch.ByteTensor(objects['difficulties'])  # (n_objects)
        #print('dificulties=',difficulties)
        # Discard difficult objects, if desired
        # if not self.keep_difficult:
        #     print('Dificulties are DISABLED')
        #     boxes = boxes[1 - difficulties]
        #     labels = labels[1 - difficulties]
        #     difficulties = difficulties[1 - difficulties]
        #     #subtract -1 from img id
        # # Apply transformations
        image, boxes, labels = transform(image, boxes, labels, split=self.split)

        return image, boxes, labels

    def __len__(self):
        return len(self.images)

    def collate_fn(self, batch):
        """
        Since each image may have a different number of objects, we need a collate function (to be passed to the DataLoader).

        This describes how to combine these tensors of different sizes. We use lists.

        Note: this need not be defined in this Class, can be standalone.

        :param batch: an iterable of N sets from __getitem__()
        :return: a tensor of images, lists of varying-size tensors of bounding boxes, labels, and difficulties
        """

        images = list()
        boxes = list()
        labels = list()
        #difficulties = list()

        for b in batch:
            images.append(b[0])
            boxes.append(b[1])
            labels.append(b[2])
            #difficulties.append(b[3])

        images = torch.stack(images, dim=0)
        # print('finalbx',boxes)
        return images, boxes, labels  # tensor (N, 3, 300, 300), 3 lists of N tensors each


#test
data_folder = '/data/home/sas44100/g_laufwerk/tutorial/first_implementation/object_detection/data'
train_dataset = PascalVOCDataset(data_folder,
                                     split='train_5'
                                     
)